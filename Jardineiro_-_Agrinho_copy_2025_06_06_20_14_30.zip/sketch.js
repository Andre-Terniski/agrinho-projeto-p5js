let jardineiro;
let plantas = [];
let temperatura = 10;
let totalArvores = 0;

let imgMachado; // Renomeado para maior clareza
let machado; // Agora será uma instância da classe Machado

// Variáveis para controlar o aparecimento do machado
let machadoVisivel = false;
let tempoProximoMachado = 0;
const INTERVALO_MACHADO_MIN = 3000; // Machado aparece entre 3 e 10 segundos
const INTERVALO_MACHADO_MAX = 10000;
const TEMPO_VIDA_MACHADO = 1500; // Machado visível por 1.5 segundos

function preload() {
  imgMachado = loadImage("machado.png"); // Carrega a imagem do machado
}

function setup() {
  createCanvas(600, 400);
  jardineiro = new Jardineiro(width / 2, height - 50);
  machado = new Machado(); // Cria a instância do machado

  // Define o tempo para a primeira aparição do machado
  tempoProximoMachado =
    millis() + random(INTERVALO_MACHADO_MIN, INTERVALO_MACHADO_MAX);
}

function draw() {
  // Cor do fundo muda de acordo com a quantidade de árvores
  let corFundo = lerpColor(
    color(217, 112, 26),
    color(219, 239, 208),
    map(totalArvores, 0, 100, 0, 1)
  );
  background(corFundo);

  mostrarInformacao();

  // Lógica para o machado aparecer e desaparecer
  if (!machadoVisivel && millis() > tempoProximoMachado) {
    machado.aparecer();
  }

  if (machadoVisivel) {
    machado.exibir();
    // Verifica se o machado atingiu uma árvore
    for (let i = plantas.length - 1; i >= 0; i--) {
      if (machado.verificaColisao(plantas[i])) {
        plantas[i].cortar(); // Marca a árvore como cortada
        machadoVisivel = false; // Machado desaparece após cortar
        tempoProximoMachado =
          millis() + random(INTERVALO_MACHADO_MIN, INTERVALO_MACHADO_MAX);
        break; // Sai do loop para não cortar múltiplas árvores com um machado
      }
    }
    // Se o machado não atingiu uma árvore e seu tempo de vida acabou
    if (millis() - machado.tempoAparecimento > TEMPO_VIDA_MACHADO) {
      machadoVisivel = false;
      tempoProximoMachado =
        millis() + random(INTERVALO_MACHADO_MIN, INTERVALO_MACHADO_MAX);
    }
  }

  jardineiro.mostrar();
  jardineiro.atualizar();

  // Desenha todas as plantas
  for (let arvore of plantas) {
    arvore.mostrar();
  }

  // Atualiza a temperatura baseada nas árvores vivas
  let arvoresVivas = plantas.filter((arvore) => !arvore.cortada).length;
  temperatura = 10 - arvoresVivas * 0.1; // Cada árvore viva reduz a temperatura um pouco
  if (temperatura < 0) temperatura = 0; // Garante que a temperatura não seja negativa
}

function mostrarInformacao() {
  textSize(20);
  fill(0); // Cor do texto
  text("Temperatura: " + temperatura.toFixed(2), 10, 30);
  text(
    "Árvores plantadas: " + plantas.filter((arvore) => !arvore.cortada).length,
    10,
    50
  ); // Conta apenas árvores não cortadas
  text("Para movimentar o personagem use as setas do teclado.", 10, 70);
  text("Pressione 'Espaço' para plantar ou 'P' para replantar.", 10, 90);
}

class Jardineiro {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.emoji = "👨‍🌾";
    this.velocidade = 3;
  }

  atualizar() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.velocidade;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.velocidade;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.velocidade;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.velocidade;
    }

    // Limita o jardineiro dentro da tela
    this.x = constrain(this.x, 0, width - 32); // 32 é o tamanho aproximado do emoji
    this.y = constrain(this.y, 0, height - 32);
  }

  mostrar() {
    textSize(32);
    text(this.emoji, this.x, this.y);
  }

  // Novo método para o jardineiro tentar replantar uma árvore
  tentarReplantar(arvore) {
    // Verifica se a árvore está cortada e se o jardineiro está perto dela
    // Usamos dist() para calcular a distância entre o jardineiro e a árvore
    let distancia = dist(this.x, this.y, arvore.x, arvore.y);
    if (arvore.cortada && distancia < 50) {
      // Distância arbitrária para interação
      arvore.replantar();
      temperatura -= 0.5; // Replantar também ajuda a temperatura
      if (temperatura < 0) temperatura = 0;
      return true;
    }
    return false;
  }
}

function keyPressed() {
  // Tecla Espaço ou 'P' para plantar/replantar
  if (key === " " || key === "p") {
    let plantou = false;
    // Primeiro, tenta replantar uma árvore cortada que esteja perto
    for (let arvore of plantas) {
      if (jardineiro.tentarReplantar(arvore)) {
        plantou = true;
        break; // Replanta apenas uma por vez
      }
    }

    // Se não replantou nenhuma árvore cortada, planta uma nova
    if (!plantou) {
      let arvore = new Arvore(jardineiro.x, jardineiro.y);
      plantas.push(arvore);
      totalArvores++; // Este contador é para o total de árvores plantadas na história do jogo
      temperatura -= 3; // Plantar uma nova árvore tem um impacto maior na temperatura
      if (temperatura < 0) temperatura = 0;
    }
  }
}

class Arvore {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.emojiVivo = "🌳";
    this.emojiCortado = "🪵"; // Emoji para toco de árvore
    this.cortada = false; // Novo estado da árvore
  }

  mostrar() {
    textSize(32);
    if (this.cortada) {
      text(this.emojiCortado, this.x, this.y);
    } else {
      text(this.emojiVivo, this.x, this.y);
    }
  }

  cortar() {
    this.cortada = true;
    temperatura += 5; // Cortar a árvore aumenta a temperatura
  }

  replantar() {
    this.cortada = false;
  }
}

class Machado {
  constructor() {
    this.x = 0;
    this.y = 0;
    this.largura = 80; // Tamanho da imagem do machado
    this.altura = 80;
    this.tempoAparecimento = 0;
  }

  aparecer() {
    // Posição aleatória na tela, ajustando para não sair da tela
    this.x = random(0, width - this.largura);
    this.y = random(0, height - this.altura);
    machadoVisivel = true;
    this.tempoAparecimento = millis(); // Registra o tempo que o machado apareceu
  }

  exibir() {
    image(imgMachado, this.x, this.y, this.largura, this.altura);
  }

  // Verifica se o machado colidiu com uma árvore
  verificaColisao(arvore) {
    if (!arvore.cortada) {
      // Só verifica colisão se a árvore não estiver cortada
      // Verifica a sobreposição de retângulos (bounding box collision)
      // Lembre-se que o emoji da árvore tem um tamanho de 32x32px
      if (
        this.x < arvore.x + 32 &&
        this.x + this.largura > arvore.x &&
        this.y < arvore.y + 32 &&
        this.y + this.altura > arvore.y
      ) {
        return true;
      }
    }
    return false;
  }
}
